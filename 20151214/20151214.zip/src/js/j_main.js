;(function(){
  // ontouchstart
  // ontouchmove
  // ontouchend
  $(function(){
     
  });



})();
